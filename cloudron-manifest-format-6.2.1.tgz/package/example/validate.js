import manifestformat from 'cloudron-manifestformat';

const manifestfile = 'CloudronManifest.json';

let result = manifestformat.parseFile(manifestfile);

if (result.error === null) {
    if (process.argv.length === 3 && process.argv[2] === '--strict') {
        console.info('Strict validation...');
        result = manifestformat.checkAppstoreRequirements(result.manifest);
        if (result !== null) {
            console.error(result.message);
            process.exit(2);
        }
    }

    console.info(manifestfile + ' validated successfully.');
} else {
    console.error(result.error.message);
    process.exit(1);
}

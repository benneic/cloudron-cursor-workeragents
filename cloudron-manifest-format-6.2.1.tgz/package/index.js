import assert from 'node:assert';
import Ajv from 'ajv';
import { CronJob } from 'cron';
import safe from '@cloudron/safetydance';
import semver from 'semver';

function isId(id) {
    const parts = id.split('.');
    if (parts.length == 1) return false;
    for (const part of parts) {
        if (!/^[a-z0-9][-a-z0-9_]*$/.test(part)) return false;
    }
    return true;
}

// package semver is not really a semver because 1.2.3-1 > 1.2.3
function isValidPkgSemver(data) {
    if (!semver.valid(data)) return false;

    const p = semver.parse(data);

    // semverToInt limitation for now
    if (p.major > 255 || p.minor > 255 || p.patch > 255) return false;

    if (p.prerelease.length > 1) return false;
    if (p.prerelease.length === 1) {
        if (typeof p.prerelease[0] !== 'number') return false;
        if (p.prerelease[0] > 255) return false;
    }
    if (p.build.length !== 0) return false;

    return true;
}

// allErrors returns all the errors and not just the first one
const ajv = new Ajv({ allErrors: true, strict: false });

ajv.addFormat('semver', {
    type: 'string',
    validate: (data) => semver.valid(data) !== null
});

ajv.addFormat('pkgsemver', {
    type: 'string',
    validate: (data) => {
        if (!semver.valid(data)) return false;

        const p = semver.parse(data);

        if (p.major > 255) return false;
        if (p.minor > 255) return false;
        if (p.patch > 255) return false;

        if (p.prerelease.length > 1) return false;
        if (p.prerelease.length === 1) {
            if (typeof p.prerelease[0] !== 'number') return false;
            if (p.prerelease[0] > 255) return false;
        }
        if (p.build.length !== 0) return false;

        return true;
    }
});

ajv.addFormat('envvar', {
    type: 'object',
    validate: (data) => {
        if (typeof data !== 'object' || data === null) return true;
        for (const env of Object.keys(data)) {
            if (env.startsWith('CLOUDRON_')) return false;
        }
        return true;
    }
});

ajv.addFormat('uri', {
  type: 'string',
  validate: (data) => {
    try {
      const url = new URL(data);
      return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
      return false;
    }
  }
});

ajv.addFormat('reverseDomain', {
    type: 'string',
    validate: (data) => isId(data)
});

ajv.addFormat('email', {
    type: 'string',
    validate: (data) => data.includes('@')
});

ajv.addFormat('cronpattern', {
    type: 'string',
    validate: (data) => {
        const NAMED_PATTERNS = ['@service', '@reboot', '@yearly', '@annually', '@monthly', '@weekly', '@daily', '@hourly'];
        if (NAMED_PATTERNS.includes(data)) return true;

        if (data.split(' ').length !== 5) return false; // second is disallowed

        try {
            new CronJob('00 ' + data, function() { }); // second is disallowed
            return true;
        } catch {
            return false;
        }
    }
});

ajv.addFormat('byteString', {
    type: 'string',
    validate: (data) => {
        const results = data.match(/^((-|\+)?(\d+(?:\.\d+)?)) *(kb|mb|gb|tb)$/i);
        return results !== null;
    }
});

const SCHEMA_V1 = {
    type: 'object',
    additionalProperties: false,
    properties: {
        'addons': {
            type: 'object',
            additionalProperties: false,
            patternProperties: {
                '^(ldap|redis|sendmail|oauth|mysql|postgresql|mongodb|localstorage|email|recvmail|tls|turn|docker|proxyAuth|headless|scim)$': {
                    type: 'object',
                    additionalProperties: true
                }
            },
            properties: {
                'oidc': {
                    type: 'object',
                    properties: {
                        loginRedirectUri: {
                            type: 'string'
                        }
                    },
                    additionalProperties: true,
                    required: ['loginRedirectUri']
                },
                'scheduler': {
                    type: 'object',
                    patternProperties: {
                        '^[a-zA-Z0-9_]+$': {
                            type: 'object',
                            properties: {
                                'schedule': {
                                    type: 'string',
                                    format: 'cronpattern'
                                },
                                'command': {
                                    type: 'string'
                                }
                            }
                        }
                    }
                }
            }
        },
        'aliasableDomain': {
            type: 'boolean'
        },
        'author': {
            type: 'string',
            minLength: 2
        },
        'backupCommand': {
            type: 'string',
            minLength: 1
        },
        'capabilities': {
            type: 'array',
            items: {
                type: 'string',
                pattern: '^(net_admin|mlock|ping|vaapi)$'
            },
            uniqueItems: true
        },
        'checklist': {
            type: 'object',
            patternProperties: {
                '^[a-zA-Z0-9_-]+$': {
                    type: 'object',
                    properties: {
                        sso: {
                            type: 'boolean'
                        },
                        message: {
                            type: 'string'
                        }
                    },
                    required: ['message']
                }
            }
        },
        'changelog': {
            type: 'string',
            minLength: 5
        },
        'configurePath': {
            type: 'string',
            minLength: 1
        },
        'contactEmail': {
            type: 'string',
            format: 'email'
        },
        'customAuth': {
            type: 'boolean'
        },
        'description': {
            type: 'string',
            minLength: 5
        },
        'dockerImage': {
            type: 'string',
            minLength: 1
        },
        'documentationUrl': {
            type: 'string',
            format: 'uri',
            minLength: 1
        },
        'forumUrl': {
            type: 'string',
            format: 'uri',
            minLength: 1
        },
        'healthCheckPath': {
            type: 'string',
            minLength: 1
        },
        'httpPort': {
            type: 'integer',
            minimum: 0,
            maximum: 65535
        },
        'httpPorts': {
            type: 'object',
            format: 'envvar',
            patternProperties: {
                '^[a-zA-Z0-9_]+$': {
                    type: 'object',
                    properties: {
                        'title': {
                            type: 'string',
                            minLength: 2
                        },
                        'description': {
                            type: 'string',
                            minLength: 5
                        },
                        'containerPort': {
                            type: 'integer',
                            minimum: 1,
                            maximum: 65535
                        },
                        'defaultValue': {
                            type: 'string',
                            minLength: 1
                        },
                        'aliasableDomain': {
                            type: 'boolean'
                        }
                    },
                    required: ['title', 'description', 'containerPort']
                }
            }
        },
        // to be deprecated in favor of iconUrl
        'icon': {
            type: 'string'
        },
        'iconUrl': {
            type: 'string',
            format: 'uri',
            minLength: 1
        },
        'id': {
            type: 'string',
            format: 'reverseDomain'
        },
        'logPaths': {
            type: 'array',
            uniqueItems: true,
            items: {
                type: 'string',
                minLength: 1
            }
        },
        'manifestVersion': {
            type: 'integer',
            minimum: 1,
            maximum: 2
        },
        'maxBoxVersion': {
            type: 'string',
            format: 'semver'
        },
        'mediaLinks': {
            type: 'array',
            uniqueItems: true,
            items: {
                type: 'string',
                format: 'uri'
            }
        },
        'memoryLimit': {
            oneOf: [{
                type: 'integer',
                minimum: 1
            }, {
                type: 'string',
                format: 'byteString'
            }]
        },
        'minBoxVersion': {
            type: 'string',
            format: 'semver'
        },
        'multiDomain': {
            type: 'boolean'
        },
        'optionalSso': {
            type: 'boolean'
        },
        'packagerName': {
            type: 'string',
            minLength: 1,
        },
        'packagerUrl': {
            type: 'string',
            format: 'uri',
            minLength: 1
        },
        'upstreamLicense': {
            type: 'object',
            properties: {
                'name': {
                    type: 'string',
                    minLength: 1
                },
                'url': {
                    type: 'string',
                    format: 'uri',
                    minLength: 1
                }
            },
            required: ['name', 'url'],
            additionalProperties: false
        },
        'persistentDirs': {
            type: 'array',
            uniqueItems: true,
            items: {
                type: 'string',
                minLength: 1
            }
        },
        'postInstallMessage': {
            type: 'string',
            minLength: 5
        },
        'restoreCommand': {
            type: 'string',
            minLength: 1
        },
        'runtimeDirs': {
            type: 'array',
            uniqueItems: true,
            items: {
                type: 'string',
                minLength: 1
            }
        },
        'tagline': {
            type: 'string',
            minLength: 5
        },
        'tags': {
            type: 'array',
            items: {
                type: 'string'
            },
            uniqueItems: true
        },
        'targetBoxVersion': {
            type: 'string',
            format: 'semver'
        },
        'tcpPorts': {
            type: 'object',
            format: 'envvar',
            propertyNames: {
                pattern: '^[A-Z0-9_]+$'
            },
            additionalProperties: {
                type: 'object',
                properties: {
                    'title': {
                        type: 'string',
                        minLength: 2
                    },
                    'description': {
                        type: 'string',
                        minLength: 5
                    },
                    'containerPort': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 65535
                    },
                    'defaultValue': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 65535
                    },
                    'enabledByDefault': {
                        type: 'boolean'
                    },
                    'portCount': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 1000
                    },
                    'readOnly': {
                        type: 'boolean'
                    }
                },
                required: ['title', 'description']
            }
        },
        'title': {
            type: 'string',
            minLength: 2
        },
        'udpPorts': {
            type: 'object',
            format: 'envvar',
            propertyNames: {
                pattern: '^[A-Z0-9_]+$'
            },
            additionalProperties: {
                type: 'object',
                properties: {
                    'title': {
                        type: 'string',
                        minLength: 2
                    },
                    'description': {
                        type: 'string',
                        minLength: 5
                    },
                    'containerPort': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 65535
                    },
                    'defaultValue': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 65535
                    },
                    'portCount': {
                        type: 'integer',
                        minimum: 1,
                        maximum: 1000
                    },
                    'readOnly': {
                        type: 'boolean'
                    },
                    'enabledByDefault': {
                        type: 'boolean'
                    }
                },
                required: ['title', 'description']
            }
        },
        'upstreamVersion': {
            type: 'string',
            minLength: 1
        },
        'version': {
            type: 'string',
            format: 'pkgsemver'
        },
        'website': {
            type: 'string',
            format: 'uri'
        }
    },
    required: ['manifestVersion', 'version', 'httpPort']
};

// Compile the schema once for performance
const validateManifest = ajv.compile(SCHEMA_V1);

function semverToInt(version) {
    var parsed = semver.parse(version);

    // prerelease is an array. x.y.z-1.foo gets parsed as [ 1, 'foo' ]
    var packageVersion = parsed.prerelease[0];
    if (typeof packageVersion !== 'number') packageVersion = 0;

    // assumes major, minor, path are <= 255 . in javascript, >>> 0 i unsigned shift
    return ((parsed.major << 24) | (parsed.minor << 16) | (parsed.patch << 8) | packageVersion) >>> 0;
}

function packageVersionCompare(a, b) {
    return semverToInt(a) - semverToInt(b);
}

function formatAjvError(error) {
    let message = error.message;
    if (error.instancePath) {
        message += ' @ ' + error.instancePath;
    }
    const params = error.params;
    if (params && typeof params === 'object') {
        if (error.keyword === 'additionalProperties' && typeof params.additionalProperty === 'string') {
            message += ` (${JSON.stringify(params.additionalProperty)})`;
        }
        if (error.keyword === 'required' && typeof params.missingProperty === 'string') {
            message += ` (${params.missingProperty})`;
        }
    }
    return message;
}

function parse(manifest) {
    if (!manifest || typeof manifest !== 'object') return new Error('Expecting object');

    const valid = validateManifest(manifest);
    if (!valid) {
        const error = validateManifest.errors[0];
        return new Error(formatAjvError(error));
    }

    let envVars = [];
    if ('tcpPorts' in manifest) envVars = envVars.concat(Object.keys(manifest.tcpPorts));
    if ('udpPorts' in manifest) envVars = envVars.concat(Object.keys(manifest.udpPorts));
    if ('httpPorts' in manifest) envVars = envVars.concat(Object.keys(manifest.httpPorts));
    if ([...new Set(envVars)].length !== envVars.length) return new Error('Duplicate env vars in tcpPorts/udpPorts/httpPorts');

    // https://docs.docker.com/engine/reference/commandline/tag/#extended-description
    if ('dockerImage' in manifest) {
        if (manifest.dockerImage.includes('//')) return new Error('Invalid docker image name'); // seems to be a common mistake to paste 'https://'
    }

    if ('runtimeDirs' in manifest) {
        const ALLOWED_DIRS = ['/root', '/app/code', '/home/cloudron'];
        for (const dir of manifest.runtimeDirs) {
            if (ALLOWED_DIRS.every(ad => dir !== ad && !dir.startsWith(ad))) return new Error('Invalid run time dir');
        }
    }

    if ('persistentDirs' in manifest) {
        const DISALLOWED_PREFIXES = ['/app/data', '/tmp', '/run'];
        for (const dir of manifest.persistentDirs) {
            if (!dir.startsWith('/')) return new Error('persistentDirs must be absolute paths');
            if (DISALLOWED_PREFIXES.some(p => dir === p || dir.startsWith(p + '/'))) return new Error(`persistentDirs path "${dir}" overlaps with a reserved path`);
            if (manifest.runtimeDirs?.includes(dir)) return new Error(`persistentDirs path "${dir}" overlaps with runtimeDirs`);
        }
    }

    if ('restoreCommand' in manifest && !('backupCommand' in manifest)) return new Error('restoreCommand requires backupCommand');

    const addons = manifest.addons;
    if (addons?.localstorage?.sqlite) {
        const sqlite = addons.localstorage.sqlite;
        if (!sqlite || typeof sqlite !== 'object') return new Error('Expecting sqlite to be an object');
        if (!sqlite.paths) return new Error('sqlite.paths is required');
        if (!Array.isArray(sqlite.paths) || sqlite.paths.some(p => typeof p !== 'string')) return new Error('Expecting sqlite.paths to be an array of strings');
    }

    return null;
}

function parseString(manifestJson) {
    assert.strictEqual(typeof manifestJson, 'string');

    const manifest = safe.JSON.parse(manifestJson);

    const error = manifest ? parse(manifest) : new Error(`Unable to parse manifest: ${safe.error.message}`);

    return { manifest: error ? null : manifest, error: error ? new Error(error.message) : null };
}

function parseFile(manifestFile) {
    assert.strictEqual(typeof manifestFile, 'string');

    const manifestJson = safe.fs.readFileSync(manifestFile, 'utf8');
    if (!manifestJson) return { manifest: null, error: new Error(`Unable to read file: ${safe.error.message}`) };

    return parseString(manifestJson);
}

function parseVersions(versionsRoot) {
    if (!versionsRoot || typeof versionsRoot !== 'object') return new Error('expecting object');

    if (typeof versionsRoot.stable !== 'boolean') return new Error('expecting stable to be a boolean');

    const versions = versionsRoot.versions;
    if (!versions || typeof versions !== 'object') return new Error('expecting "versions" field to be an object');

    for (const version of Object.keys(versions)) {
        if (!isValidPkgSemver(version)) return new Error(`invalid version key: ${version}`);

        const manifest = versions[version]?.manifest;
        const manifestError = parse(manifest);
        if (manifestError) return new Error(`Invalid manifest in ${version}: ${manifestError.message}`);
        if (manifest.version !== version) return new Error(`version mismatch in manifest: ${version}`);

        if (isNaN(new Date(versions[version].creationDate))) return new Error(`invalid ts in ${version}`);
        if (isNaN(new Date(versions[version].ts))) return new Error(`invalid ts in ${version}`);
        if (typeof versions[version].publishState !== 'string') return new Error(`invalid publishState in ${version}`);
    }

    return null;
}

function checkCommonRequirements(manifest) {
    const requiredFields = ['id', 'title', 'description', 'tagline', 'website', 'contactEmail', 'author', 'tags', 'changelog'];
    for (const field of requiredFields) {
        if (!(field in manifest)) return new Error(`${field} is missing in manifest`);
        if (!manifest[field]) return new Error(`${field} is empty in manifest`);
    }

    if (!('mediaLinks' in manifest)) return new Error('mediaLinks is missing in manifest');
    if (manifest.mediaLinks.length === 0) return new Error('mediaLinks is empty in manifest');

    if (manifest.addons && Object.keys(manifest.addons).some(function (addon) { return /^_.*$/.test(addon); })) {
        return new Error('cannot publish with reserved addons');
    }

    if (!('healthCheckPath' in manifest)) return new Error('healthCheckPath is missing in manifest');

    if (manifest.upstreamVersion && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '7.1.0'))) return new Error('upstreamVersion requires minBoxVersion of atleast 7.1.0');
    if (manifest.logPaths && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '7.1.0'))) return new Error('logPaths requires minBoxVersion of atleast 7.1.0');
    if (manifest.runtimeDirs && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '7.3.3'))) return new Error('runtimeDirs requires minBoxVersion of atleast 7.3.3');

    for (const n in manifest.tcpPorts) {
        if ('portCount' in manifest.tcpPorts[n] && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '7.7.0'))) return new Error('tcpPorts.portCount requires minBoxVersion of atleast 7.7.0');
        if ('enabledByDefault' in manifest.tcpPorts[n] && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.0.0'))) return new Error('tcpPorts.enabledByDefault requires minBoxVersion of atleast 9.0.0');
    }
    for (const n in manifest.udpPorts) {
        if ('portCount' in manifest.udpPorts[n] && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '7.7.0'))) return new Error('udpPorts.portCount requires minBoxVersion of atleast 7.7.0');
        if ('enabledByDefault' in manifest.udpPorts[n] && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.0.0'))) return new Error('udpPorts.enabledByDefault requires minBoxVersion of atleast 9.0.0');
    }

    if ('checklist' in manifest && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '8.0.0'))) return new Error('checklist requires minBoxVersion of atleast 8.0.0');

    if (manifest.addons?.localstorage?.sqlite && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '8.2.0'))) return new Error('sqlite addon requires minBoxVersion of atleast 8.2.0');

    if (manifest.addons?.sendmail?.requiresValidCertificate && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.0.0'))) return new Error('requiresValidCertificate requires minBoxVersion of atleast 9.0.0');

    if (manifest.addons?.scim && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.2.0'))) return new Error('scim addon requires minBoxVersion of atleast 9.2.0');

    if (manifest.iconUrl && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('manifest.iconUrl requires minBoxVersion of atleast 9.1.0');
    if (manifest.packagerName && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('manifest.packagerName requires minBoxVersion of atleast 9.1.0');
    if (manifest.packagerUrl && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('manifest.packagerUrl requires minBoxVersion of atleast 9.1.0');
    if (manifest.upstreamLicense && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('manifest.upstreamLicense requires minBoxVersion of atleast 9.1.0');

    if (manifest.persistentDirs && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('persistentDirs requires minBoxVersion of atleast 9.1.0');
    if (manifest.backupCommand && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('backupCommand requires minBoxVersion of atleast 9.1.0');
    if (manifest.restoreCommand && (!manifest.minBoxVersion || semver.lt(manifest.minBoxVersion, '9.1.0'))) return new Error('restoreCommand requires minBoxVersion of atleast 9.1.0');

    return null;
}

// tags which are required by appstore (but not required for installation)
function checkAppstoreRequirements(manifest) {
    assert(typeof manifest === 'object');

    if (!isValidPkgSemver(manifest.version)) return new Error('Invalid version format');

    if (!('dockerImage' in manifest)) return new Error('dockerImage is missing in manifest');
    if (!manifest.dockerImage.startsWith(`cloudron/${manifest.id}:`)) return new Error(`dockerImage must be in cloudron/appid format (${manifest.dockerImage})`);

    // at some point we will migrate this to iconUrl
    if (!('icon' in manifest)) return new Error(`icon is missing in manifest`);
    if (!manifest['icon']) return new Error(`icon is empty in manifest`);

    return checkCommonRequirements(manifest);
}

// tags which are required by versions file (but not required for installation)
function checkVersionsRequirements(manifest) {
    if (!('iconUrl' in manifest)) return new Error(`iconUrl is missing in manifest`);
    if (!manifest['iconUrl']) return new Error(`iconUrl is empty in manifest`);

    if (!manifest['packagerName']) return new Error(`packagerName is empty in manifest`);
    if (!manifest['packagerUrl']) return new Error(`packagerUrl is empty in manifest`);

    return checkCommonRequirements(manifest);
}

export default {
    isId,
    parse,
    parseString,
    parseFile,
    checkAppstoreRequirements,
    checkVersionsRequirements,
    packageVersionCompare,

    parseVersions,

    SCHEMA_V1
};

import { describe, it } from 'mocha';
import assert from 'node:assert/strict';
import manifestFormat from '../index.js';

describe('parseManifest', function () {
    const manifest = {
        id: 'io.cloudron.test',
        title: 'Bar App',
        description: 'Long long ago, there was foo',
        tagline: 'Not your usual Foo App',
        author: 'Herbert Burgermeister',
        manifestVersion: 1,
        version: '0.1.2',
        dockerImage: 'girish/foo:0.2',
        httpPort: 23,
        website: 'https://example.com',
        contactEmail: 'support@example.com'
    };

    function expectError(manifestCopy) {
        assert.ok(manifestFormat.parseString(JSON.stringify(manifestCopy)).error instanceof Error);
    }

    function expectSuccess(manifestCopy) {
        assert.deepStrictEqual(manifestFormat.parseString(JSON.stringify(manifestCopy)).manifest, manifestCopy);
    }

    describe('basic validation', function () {
        it('errors for empty string', function () {
            assert.ok(manifestFormat.parseString('').error instanceof Error);
        });

        it('errors for invalid json', function () {
            assert.ok(manifestFormat.parseString('garbage').error instanceof Error);
        });

        it('succeeds for minimal valid manifest', function () {
            expectSuccess(manifest);
        });

        it('succeeds for maximal valid manifest', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.minBoxVersion = '0.0.1';
            manifestCopy.maxBoxVersion = '1.0.0';
            manifestCopy.targetBoxVersion = '1.0.0';
            manifestCopy.addons = {
                'mysql': { },
                'postgresql': { },
                'mongodb': { cacheSize: 34 }
            };
            manifestCopy.changelog = 'Change upload size limit';
            manifestCopy.tags = [ 'wiki', 'collaboration' ];
            manifestCopy.capabilities = [ 'net_admin' ];
            expectSuccess(manifestCopy);
        });
    });

    describe('required fields', function () {
        manifestFormat.SCHEMA_V1.required.forEach(function (key) {
            it('errors for missing ' + key, function () {
                const manifestCopy = Object.assign({ }, manifest);
                delete manifestCopy[key];
                expectError(manifestCopy);
            });
        });
    });

    describe('id', function () {
        const badIds = ['simply', '12de', 'in..x', 'no.quest?on'];
        badIds.forEach(function (badId) {
            it(`fails for bad id: ${badId}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.id = badId;
                expectError(manifestCopy);
            });
        });
    });

    describe('version', function () {
        const badVersions = ['0.2', '0.2.3-build', '0.2.3-1-2', '0.2.4-04'];
        badVersions.forEach(function (badVersion) {
            it(`fails for bad version: ${badVersion}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.version = badVersion;
                expectError(manifestCopy);
            });
        });
        const goodVersions = ['0.0.3', '0.2.3-4' ];
        goodVersions.forEach(function (goodVersion) {
            it(`succeeds for good version: ${goodVersion}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.version = goodVersion;
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('manifestVersion', function () {
        it('fails for bad manifestVersion', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.manifestVersion = 3;
            expectError(manifestCopy);
        });
    });

    describe('boxVersion', function () {
        [
            { field: 'minBoxVersion', badValue: '0.2' },
            { field: 'maxBoxVersion', badValue: '0.2' },
            { field: 'targetBoxVersion', badValue: '0.2' }
        ].forEach(function ({ field, badValue }) {
            it(`fails for bad ${field}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy[field] = badValue;
                expectError(manifestCopy);
            });
        });
    });

    describe('addons', function () {
        const invalidAddons = [
            { value: null, desc: 'null' },
            { value: [ 23 ], desc: 'array with number' },
            { value: [ 'mysql', 34 ], desc: 'array with mixed types' },
            { value: [ null, 'mysql' ], desc: 'array with null' },
            { value: { 'andy': { } }, desc: 'unknown addon' }
        ];

        invalidAddons.forEach(function ({ value, desc }) {
            it(`fails for invalid addon: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.addons = value;
                expectError(manifestCopy);
            });
        });
    });

    describe('scheduler addon', function () {
        const badSchedulers = [
            { value: { 'nice': 'try' }, desc: 'invalid task format' },
            { value: { 'task1': { schedule: '1 2 3 4 m', command: 'blah' } }, desc: 'invalid cron pattern' }
        ];

        badSchedulers.forEach(function ({ value, desc }) {
            it(`fails for bad scheduler: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.addons = { scheduler: value };
                expectError(manifestCopy);
            });
        });

        const goodSchedulers = [
            { value: { 'task1': { schedule: '* * * * *', command: 'blah' } }, desc: 'standard cron pattern' },
            { value: { 'task1': { schedule: '@service', command: 'blah' } }, desc: 'named pattern' }
        ];

        goodSchedulers.forEach(function ({ value, desc }) {
            it(`succeeds for good scheduler: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.addons = { 'scheduler': value };
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('localstorage/sqlite addon', function () {
        it('succeeds for good sqlite', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = {
                'localstorage': {
                    'sqlite': { paths: ['/whatever'] }
                }
            };
            expectSuccess(manifestCopy);
        });
    });

    describe('proxyAuth addon', function () {
        it('succeeds for proxyAuth', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = { proxyAuth: {} };
            expectSuccess(manifestCopy);
        });
    });

    describe('headless addon', function () {
        it('succeeds for headless', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = { headless: {} };
            expectSuccess(manifestCopy);
        });
    });

    describe('oidc addon', function () {
        it('requires loginRedirectUri for oidc', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = { oidc: {} };
            expectError(manifestCopy);
        });

        it('succeeds with loginRedirectUri', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = { oidc: { loginRedirectUri: '/someUri' } };
            expectSuccess(manifestCopy);
        });

        it('succeeds with loginRedirectUri and extra properties', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.addons = { oidc: { loginRedirectUri: '/someUri', logoutRedirectUri: '' } };
            expectSuccess(manifestCopy);
        });
    });

    describe('capabilities', function () {
        it('fails for bad capabilities', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.capabilities = [ 'test' ];
            expectError(manifestCopy);
        });

        const goodCapabilities = [
            { value: [], desc: 'empty array' },
            { value: [ 'net_admin', 'mlock', 'ping' ], desc: 'valid capabilities' }
        ];

        goodCapabilities.forEach(function ({ value, desc }) {
            it(`succeeds for good capabilities: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.capabilities = value;
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('changelog', function () {
        const badChangelogs = [
            { value: 34, desc: 'number' },
            { value: [], desc: 'empty array' },
            { value: [ null ], desc: 'array with null' },
            { value: [ 56 ], desc: 'array with number' }
        ];

        badChangelogs.forEach(function ({ value, desc }) {
            it(`fails for bad changelog: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.changelog = value;
                expectError(manifestCopy);
            });
        });
    });

    describe('tcpPorts', function () {
        const badTcpPorts = [
            { value: 45, desc: 'number instead of object' },
            { value: { 'ENV$': { } }, desc: 'bad env with special char' },
            { value: { 'smallercase': { } }, desc: 'lowercase env' },
            { value: { 'CLOUDRON_OOPS': { } }, desc: 'reserved CLOUDRON_ prefix' },
            { value: { 'PORT_NAME': { } }, desc: 'missing description' },
            { value: { 'PORT_NAME': { description: 34 } }, desc: 'non-string description' },
            { value: { 'PORT_NAME': { title: 34 } }, desc: 'non-string title' },
            { value: { 'PORT_NAME': { title: 't', description: 'long enough' } }, desc: 'title too short' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: 'invalid' } }, desc: 'string containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: NaN } }, desc: 'NaN containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: -2 } }, desc: 'negative containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 'invalid' } }, desc: 'string defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: NaN } }, desc: 'NaN defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: -2 } }, desc: 'negative defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: 0 } }, desc: 'zero portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: '100' } }, desc: 'string portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: NaN } }, desc: 'NaN portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: -1 } }, desc: 'negative portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: 1001 } }, desc: 'portCount too large' }
        ];

        badTcpPorts.forEach(function ({ value, desc }) {
            it(`fails for bad tcpPorts: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.tcpPorts = value;
                expectError(manifestCopy);
            });
        });

        const goodTcpPorts = [
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 546 } }, desc: 'basic valid port' },
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 65535 } }, desc: 'max port number' },
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 65535, portCount: 100 } }, desc: 'with portCount' }
        ];

        goodTcpPorts.forEach(function ({ value, desc }) {
            it(`succeeds for good tcpPorts: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.tcpPorts = value;
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('udpPorts', function () {
        const badUdpPorts = [
            { value: 45, desc: 'number instead of object' },
            { value: { 'ENV$': { } }, desc: 'bad env with special char' },
            { value: { 'smallercase': { } }, desc: 'lowercase env' },
            { value: { 'PORT_NAME': { } }, desc: 'missing description' },
            { value: { 'PORT_NAME': { description: 34 } }, desc: 'non-string description' },
            { value: { 'PORT_NAME': { title: 34 } }, desc: 'non-string title' },
            { value: { 'PORT_NAME': { title: 't', description: 'long enough' } }, desc: 'title too short' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: 'invalid' } }, desc: 'string containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: NaN } }, desc: 'NaN containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', containerPort: -2 } }, desc: 'negative containerPort' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 'invalid' } }, desc: 'string defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: NaN } }, desc: 'NaN defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: -2 } }, desc: 'negative defaultValue' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: 0 } }, desc: 'zero portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: '100' } }, desc: 'string portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: NaN } }, desc: 'NaN portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: -1 } }, desc: 'negative portCount' },
            { value: { 'PORT_NAME': { title: 'title', description: 'description', defaultValue: 4000, portCount: 1001 } }, desc: 'portCount too large' }
        ];

        badUdpPorts.forEach(function ({ value, desc }) {
            it(`fails for bad udpPorts: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.udpPorts = value;
                expectError(manifestCopy);
            });
        });

        const goodUdpPorts = [
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 546 } }, desc: 'basic valid port' },
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 65535 } }, desc: 'max port number' },
            { value: { 'PORT_NAME': { title: '12345', description: '12345', containerPort: 65535, portCount: 100 } }, desc: 'with portCount' }
        ];

        goodUdpPorts.forEach(function ({ value, desc }) {
            it(`succeeds for good udpPorts: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.udpPorts = value;
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('duplicate port keys', function () {
        it('fails for duplicate key in udp/tcpPorts', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.udpPorts = { 'UGOOD_PORT': { title: 't1', description: 'description'}, 'DUP_PORT': { title: 't2', description: 'duplicate' } };
            manifestCopy.tcpPorts = { 'DUP_PORT': { title: 't2', description: 'duplicate' }, 'TGOOD_PORT': { title: 't1', description: 'description'} };
            expectError(manifestCopy);
        });
    });

    describe('tags', function () {
        const badTags = [
            { value: [ 234 ], desc: 'number in array' },
            { value: [ 'again', 'and', 'again' ], desc: 'duplicate tags' }
        ];

        badTags.forEach(function ({ value, desc }) {
            it(`fails for bad tags: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.tags = value;
                expectError(manifestCopy);
            });
        });
    });

    describe('memoryLimit', function () {
        it('fails for bad memoryLimit', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.memoryLimit = '1p';
            expectError(manifestCopy);
        });

        const goodMemoryLimits = [
            { value: 123456, desc: 'integer' },
            { value: '10MB', desc: 'string with unit' }
        ];

        goodMemoryLimits.forEach(function ({ value, desc }) {
            it(`succeeds for memoryLimit: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.memoryLimit = value;
                expectSuccess(manifestCopy);
            });
        });
    });

    describe('mediaLinks', function () {
        const badMediaLinks = [
            { value: [ 'http://foobar.de', 'http://baz', 'foobar' ], desc: 'non-uri type' },
            { value: [ 'http://foobar.de', 'http://baz.com', 'http://foobar.de' ], desc: 'duplicates' }
        ];

        badMediaLinks.forEach(function ({ value, desc }) {
            it(`fails for bad mediaLinks: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.mediaLinks = value;
                expectError(manifestCopy);
            });
        });

        it('succeeds with valid mediaLinks', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.mediaLinks = [ 'http://foobar.de', 'http://baz.com' ];
            expectSuccess(manifestCopy);
        });
    });

    describe('documentationUrl', function () {
        it('fails with invalid documentationUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.documentationUrl = 'not-valid';
            expectError(manifestCopy);
        });

        it('succeeds with valid documentationUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.documentationUrl = 'https://cloudron.io/documentation/apps/wordpress';
            expectSuccess(manifestCopy);
        });
    });

    describe('forumUrl', function () {
        it('fails with invalid forumUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.forumUrl = 'not-valid';
            expectError(manifestCopy);
        });

        it('succeeds with valid forumUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.forumUrl = 'https://cloudron.io/documentation/apps/wordpress';
            expectSuccess(manifestCopy);
        });
    });

    describe('upstreamVersion', function () {
        it('succeeds with upstreamVersion', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.upstreamVersion = '1.2';
            expectSuccess(manifestCopy);
        });
    });

    describe('postInstallMessage', function () {
        it('succeeds with postInstallMessage', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.postInstallMessage = 'Can you see this? Thanks for installing';
            expectSuccess(manifestCopy);
        });
    });

    describe('optionalSso', function () {
        it('succeeds with optionalSso', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.optionalSso = true;
            expectSuccess(manifestCopy);
        });
    });

    describe('multiDomain (deprecated)', function () {
        it('fails for bad multiDomain', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.multiDomain = { };
            expectError(manifestCopy);
        });

        it('succeeds for boolean multiDomain', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.multiDomain = true;
            expectSuccess(manifestCopy);
        });
    });

    describe('aliasableDomain', function () {
        it('fails for bad aliasableDomain', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.aliasableDomain = { };
            expectError(manifestCopy);
        });

        it('succeeds for boolean aliasableDomain', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.aliasableDomain = true;
            expectSuccess(manifestCopy);
        });
    });

    describe('httpPort/httpPorts', function () {
        it('fails with no httpPort or httpPorts', function () {
            const manifestCopy = Object.assign({ }, manifest);
            delete manifestCopy.httpPort;
            expectError(manifestCopy);
        });

        it('succeeds with httpPorts', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.httpPorts = { 'UI_DOMAIN': { title: 'title', description: 'description', containerPort: 9000, defaultValue: 'ui.domain', aliasableDomain: true } };
            expectSuccess(manifestCopy);
        });
    });

    describe('logPaths', function () {
        it('succeeds with logPaths', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.logPaths = [ 'path1', 'path2' ];
            expectSuccess(manifestCopy);
        });
    });

    describe('runtimeDirs', function () {
        it('fails with bad runtimeDirs', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.runtimeDirs = [ '/whatever' ];
            expectError(manifestCopy);
        });

        it('succeeds with valid runtimeDirs', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.runtimeDirs = [ '/app/code', '/app/code/bar', '/home/cloudron/.npm' ];
            expectSuccess(manifestCopy);
        });
    });

    describe('persistentDirs', function () {
        it('fails with non-absolute path', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ 'relative/path' ];
            expectError(manifestCopy);
        });

        it('fails when overlapping /app/data', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/app/data' ];
            expectError(manifestCopy);
        });

        it('fails when overlapping /app/data subdir', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/app/data/something' ];
            expectError(manifestCopy);
        });

        it('fails when overlapping /tmp', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/tmp' ];
            expectError(manifestCopy);
        });

        it('fails when overlapping /run', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/run/something' ];
            expectError(manifestCopy);
        });

        it('fails when overlapping runtimeDirs', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.runtimeDirs = [ '/app/code/node_modules' ];
            manifestCopy.persistentDirs = [ '/app/code/node_modules' ];
            expectError(manifestCopy);
        });

        it('fails with duplicate entries', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/var/lib/pg', '/var/lib/pg' ];
            expectError(manifestCopy);
        });

        it('fails with empty string entry', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '' ];
            expectError(manifestCopy);
        });

        it('succeeds with valid persistentDirs', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/var/lib/elasticsearch', '/var/lib/postgresql' ];
            expectSuccess(manifestCopy);
        });

        it('succeeds with single dir', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [ '/var/lib/mydb' ];
            expectSuccess(manifestCopy);
        });

        it('succeeds with empty array', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.persistentDirs = [];
            expectSuccess(manifestCopy);
        });
    });

    describe('backupCommand', function () {
        it('fails with empty string', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.backupCommand = '';
            expectError(manifestCopy);
        });

        it('succeeds with valid command', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.backupCommand = 'pg_dump -U postgres mydb > /app/data/dump.sql';
            expectSuccess(manifestCopy);
        });
    });

    describe('restoreCommand', function () {
        it('fails with empty string', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.restoreCommand = '';
            expectError(manifestCopy);
        });

        it('fails without backupCommand', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.restoreCommand = 'psql -U postgres mydb < /app/data/dump.sql';
            expectError(manifestCopy);
        });

        it('succeeds with backupCommand present', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.backupCommand = 'pg_dump -U postgres mydb > /app/data/dump.sql';
            manifestCopy.restoreCommand = 'psql -U postgres mydb < /app/data/dump.sql';
            expectSuccess(manifestCopy);
        });
    });

    describe('packagerName', function () {
        it('fails with empty packagerName', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.packagerName = '';
            expectError(manifestCopy);
        });

        it('succeeds with valid packagerName', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.packagerName = 'Some Packager';
            expectSuccess(manifestCopy);
        });
    });

    describe('packagerUrl', function () {
        it('fails with invalid packagerUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.packagerUrl = 'not-valid';
            expectError(manifestCopy);
        });

        it('fails with empty packagerUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.packagerUrl = '';
            expectError(manifestCopy);
        });

        it('succeeds with valid packagerUrl', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.packagerUrl = 'https://example.com/packager';
            expectSuccess(manifestCopy);
        });
    });

    describe('upstreamLicense', function () {
        const badLicenses = [
            { value: 'MIT', desc: 'string instead of object' },
            { value: { name: 'MIT' }, desc: 'missing url' },
            { value: { url: 'https://opensource.org/licenses/MIT' }, desc: 'missing name' },
            { value: { name: '', url: 'https://opensource.org/licenses/MIT' }, desc: 'empty name' },
            { value: { name: 'MIT', url: 'not-a-url' }, desc: 'invalid url' },
            { value: { name: 'MIT', url: '' }, desc: 'empty url' },
            { value: { name: 'MIT', url: 'https://opensource.org/licenses/MIT', extra: 'field' }, desc: 'extra property' }
        ];

        badLicenses.forEach(function ({ value, desc }) {
            it(`fails for bad upstreamLicense: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.upstreamLicense = value;
                expectError(manifestCopy);
            });
        });

        it('succeeds with valid upstreamLicense', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.upstreamLicense = { name: 'MIT', url: 'https://opensource.org/licenses/MIT' };
            expectSuccess(manifestCopy);
        });
    });

    describe('checklist', function () {
        const badChecklists = [
            { value: 'a toplevel string it must not be', desc: 'string instead of object' },
            { value: { 'task1': 'an object it must be' }, desc: 'string value for task' },
            { value: { 'task1': { info: 'requires a message property' } }, desc: 'missing message property' },
            { value: { 'task1': { sso: 123, message: 'sso if present must be a boolean' } }, desc: 'non-boolean sso' }
        ];

        badChecklists.forEach(function ({ value, desc }) {
            it(`fails for bad checklist: ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.checklist = value;
                expectError(manifestCopy);
            });
        });

        it('succeeds for good checklist', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.checklist = {
                'task1': { message: 'really has to be done' },
                '00-first-this': { sso: false, message: 'totally valid' },
                'that': { sso: true, message: 'also totally valid' }
            };
            expectSuccess(manifestCopy);
        });
    });
});

describe('isId', function () {
    const badIds = [
        { id: 'combarzoo', desc: 'needs at least one .' },
        { id: 'com.Bar-zoo', desc: 'no capitals' },
        { id: 'c.bar.zo$', desc: 'sus character' }
    ];

    badIds.forEach(function ({ id, desc }) {
        it(`returns false for invalid id: ${desc}`, function () {
            assert.strictEqual(manifestFormat.isId(id), false);
        });
    });

    const goodIds = [
        'com.bar.zoo',
        'com.bar_zoo',
        'com.barzoo',
        'co.bar.zoo',
        'c0m.bar1',
        'com.bar-zoo'
    ];

    goodIds.forEach(function (id) {
        it(`returns true for valid id: ${id}`, function () {
            assert.strictEqual(manifestFormat.isId(id), true);
        });
    });
});

describe('checkAppstoreRequirements', function () {
    const manifest = {
        id: 'io.cloudron.test',
        title: 'Bar App',
        description: 'Long long ago, there was foo',
        tagline: 'Not your usual Foo App',
        author: 'Herbert Burgermeister',
        manifestVersion: 1,
        version: '0.1.2',
        dockerImage: 'cloudron/io.cloudron.test:0.1.2',
        httpPort: 23,
        healthCheckPath: '/',
        website: 'https://example.com',
        contactEmail: 'support@example.com',
        tags: [ 'something' ],
        mediaLinks: [ 'https://foo.ong' ],
        icon: 'file://icon.png',
        changelog: 'file://changelog.md',
        customAuth: false,
        postInstallMessage: 'Nice!',
    };

    function expectError(manifestCopy) {
        assert.ok(manifestFormat.checkAppstoreRequirements(manifestCopy) instanceof Error);
    }

    function expectSuccess(manifestCopy) {
        assert.strictEqual(manifestFormat.checkAppstoreRequirements(manifestCopy), null);
    }

    describe('required fields', function () {
        const requiredFields = ['tags', 'mediaLinks', 'icon', 'changelog'];

        requiredFields.forEach(function (field) {
            it(`fails without ${field}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                delete manifestCopy[field];
                expectError(manifestCopy);
            });
        });
    });

    describe('version', function () {
        const badVersions = [
            { version: '1.2.3-pre', desc: 'prerelease version' },
            { version: '1.2.3+build', desc: 'build version' }
        ];

        badVersions.forEach(function ({ version, desc }) {
            it(`fails with ${desc}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                manifestCopy.version = version;
                expectError(manifestCopy);
            });
        });

        it('succeeds with numeric prerelease version', function () {
            const manifestCopy = Object.assign({ }, manifest);
            manifestCopy.dockerImage = 'cloudron/io.cloudron.test:1.2.3-1-timestamp';
            manifestCopy.version = '1.2.3-1';
            expectSuccess(manifestCopy);
        });
    });

    describe('minBoxVersion requirements', function () {
        const minBoxVersionTests = [
            {
                feature: 'upstreamVersion',
                setup: (m) => { m.upstreamVersion = '3.5'; },
                minVersion: '7.1.0'
            },
            {
                feature: 'logPaths',
                setup: (m) => { m.logPaths = [ 'somefile' ]; },
                minVersion: '7.1.0'
            },
            {
                feature: 'tcpPorts.portCount',
                setup: (m) => { m.tcpPorts = { 'env': { title: 'title', description: 'description', defaultValue: 4000, portCount: 100 } }; },
                minVersion: '7.7.0'
            },
            {
                feature: 'udpPorts.portCount',
                setup: (m) => { m.udpPorts = { 'env': { title: 'title', description: 'description', defaultValue: 4000, portCount: 100 } }; },
                minVersion: '7.7.0'
            },
            {
                feature: 'checklist',
                setup: (m) => { m.checklist = { 'task': { sso: true, message: 'do this and that' } }; },
                minVersion: '8.0.0'
            },
            {
                feature: 'sqlite',
                setup: (m) => { m.addons = { 'localstorage': { 'sqlite': { path: '/some/path' } } }; },
                minVersion: '8.2.0'
            },
            {
                feature: 'requiresValidCertificate',
                setup: (m) => { m.addons = { 'sendmail': { 'requiresValidCertificate': true } }; },
                minVersion: '9.0.0'
            },
            {
                feature: 'scim',
                setup: (m) => { m.addons = { 'scim': {} }; },
                minVersion: '9.2.0'
            },
            {
                feature: 'iconUrl',
                setup: (m) => { m.iconUrl = 'https://example.com/icon.png'; },
                minVersion: '9.1.0'
            },
            {
                feature: 'packagerName',
                setup: (m) => { m.packagerName = 'Some Packager'; },
                minVersion: '9.1.0'
            },
            {
                feature: 'packagerUrl',
                setup: (m) => { m.packagerUrl = 'https://example.com/packager'; },
                minVersion: '9.1.0'
            },
            {
                feature: 'upstreamLicense',
                setup: (m) => { m.upstreamLicense = { name: 'MIT', url: 'https://opensource.org/licenses/MIT' }; },
                minVersion: '9.1.0'
            },
            {
                feature: 'persistentDirs',
                setup: (m) => { m.persistentDirs = [ '/var/lib/mydb' ]; },
                minVersion: '9.1.0'
            },
            {
                feature: 'backupCommand',
                setup: (m) => { m.backupCommand = 'pg_dump mydb > /app/data/dump.sql'; },
                minVersion: '9.1.0'
            },
            {
                feature: 'restoreCommand',
                setup: (m) => { m.backupCommand = 'pg_dump mydb > /app/data/dump.sql'; m.restoreCommand = 'psql mydb < /app/data/dump.sql'; },
                minVersion: '9.1.0'
            }
        ];

        minBoxVersionTests.forEach(function ({ feature, setup, minVersion }) {
            it(`requires ${minVersion} at least for ${feature}`, function () {
                const manifestCopy = Object.assign({ }, manifest);
                setup(manifestCopy);
                expectError(manifestCopy);
                manifestCopy.minBoxVersion = minVersion;
                expectSuccess(manifestCopy);
            });
        });
    });

    it('succeeds with all requirements', function () {
        const manifestCopy = Object.assign({ }, manifest);
        expectSuccess(manifestCopy);
    });
});

describe('checkVersionsRequirements', function () {
    const manifest = {
        id: 'io.cloudron.test',
        title: 'Bar App',
        description: 'Long long ago, there was foo',
        tagline: 'Not your usual Foo App',
        author: 'Herbert Burgermeister',
        manifestVersion: 1,
        version: '0.1.2',
        dockerImage: 'girish/foo:0.2',
        httpPort: 23,
        healthCheckPath: '/',
        website: 'https://example.com',
        contactEmail: 'support@example.com',
        tags: [ 'something' ],
        mediaLinks: [ 'https://foo.ong' ],
        iconUrl: 'https://example.com/icon.png',
        changelog: 'file://changelog.md',
        packagerName: 'Some Packager',
        packagerUrl: 'https://example.com/packager',
        minBoxVersion: '9.1.0',
    };

    function expectError(manifestCopy) {
        assert.ok(manifestFormat.checkVersionsRequirements(manifestCopy) instanceof Error);
    }

    function expectSuccess(manifestCopy) {
        assert.strictEqual(manifestFormat.checkVersionsRequirements(manifestCopy), null);
    }

    it('fails without iconUrl', function () {
        const manifestCopy = Object.assign({ }, manifest);
        delete manifestCopy.iconUrl;
        expectError(manifestCopy);
    });

    it('fails with empty iconUrl', function () {
        const manifestCopy = Object.assign({ }, manifest);
        manifestCopy.iconUrl = '';
        expectError(manifestCopy);
    });

    it('fails without packagerName', function () {
        const manifestCopy = Object.assign({ }, manifest);
        delete manifestCopy.packagerName;
        expectError(manifestCopy);
    });

    it('fails with empty packagerName', function () {
        const manifestCopy = Object.assign({ }, manifest);
        manifestCopy.packagerName = '';
        expectError(manifestCopy);
    });

    it('fails without packagerUrl', function () {
        const manifestCopy = Object.assign({ }, manifest);
        delete manifestCopy.packagerUrl;
        expectError(manifestCopy);
    });

    it('fails with empty packagerUrl', function () {
        const manifestCopy = Object.assign({ }, manifest);
        manifestCopy.packagerUrl = '';
        expectError(manifestCopy);
    });

    it('succeeds with all required fields', function () {
        const manifestCopy = Object.assign({ }, manifest);
        expectSuccess(manifestCopy);
    });
});

describe('parseVersions', function () {
    const manifest = {
        id: 'io.cloudron.test',
        title: 'Bar App',
        description: 'Long long ago, there was foo',
        tagline: 'Not your usual Foo App',
        author: 'Herbert Burgermeister',
        manifestVersion: 1,
        version: '0.1.2',
        dockerImage: 'girish/foo:0.2',
        httpPort: 23,
        website: 'https://example.com',
        contactEmail: 'support@example.com'
    };

    function expectError(v) {
        assert.ok(manifestFormat.parseVersions(v) instanceof Error);
    }

    function expectSuccess(v) {
        assert.strictEqual(manifestFormat.parseVersions(v), null);
    }

    const meta = {
        creationDate: "Thu, 05 Feb 2026 21:17:03 GMT",
        ts: "Thu, 05 Feb 2026 21:18:22 GMT",
        publishState: "testing"
    };

    const versionsRoot = {
        stable: true,
        versions: {
            '0.1.2': { manifest: structuredClone(manifest), ...meta },
            '0.2.0': { manifest: Object.assign(structuredClone(manifest), { version: '0.2.0' }), ...meta },
            '0.2.0-2': { manifest: Object.assign(structuredClone(manifest), { version: '0.2.0-2' }), ...meta },
        }
    };

    describe('stable flag', function () {
        it('fails when stable is missing', function () {
            const v = Object.assign({ }, versionsRoot);
            delete v.stable;
            expectError(v);
        });

        it('fails when stable is not a boolean', function () {
            expectError({ ...versionsRoot, stable: 'yes' });
            expectError({ ...versionsRoot, stable: 1 });
            expectError({ ...versionsRoot, stable: null });
        });

        it('succeeds when stable is false', function () {
            expectSuccess({ ...versionsRoot, stable: false });
        });

        it('succeeds when stable is true', function () {
            expectSuccess({ ...versionsRoot, stable: true });
        });
    });

    describe('fails for bad versions', function () {
        const badVersions = [
            { desc: 'string', value: 'just a string' },
            { desc: 'null', value: null },
            { desc: 'object', value: { 'random': 'bar' } },
            { desc: 'non-semver', value: { 'badversion': { manifest, ...meta } } },
            { desc: 'semver mismatch', value: { '2.3.4': { manifest, ...meta } } },
            { desc: 'bad creationDate', value: { '0.1.2': { manifest, creationDate: 'bad', ts: new Date().toUTCString(), publishState: 'testing' } } },
            { desc: 'bad ts', value: { '0.1.2': { manifest, creationDate: new Date().toUTCString(), ts: 'bod', publishState: 'testing' } } },
            { desc: 'bad publishState', value: { '0.1.2': { manifest, creationDate: new Date().toUTCString(), ts: new Date().toUTCString(), publishState: 34 } } },
        ];
        badVersions.forEach(function (v) {
            it(`fails for bad versions: ${v.desc}`, function () {
                expectError(v.value);
                expectError({ stable: true, versions: v.value });
            });
        });
    });

    it('succeeds for good versions', function () {
        expectSuccess(versionsRoot);
    });
});
